# Python Gunicorn Runner

A Docker image for running **[Python WSGI](https://wsgi.readthedocs.io/en/latest/)** applications with **[Gunicorn](https://gunicorn.org/)** in OpenShift.

The image extends [produban/python:2.0.6.RELEASE](https://registry.global.ccc.srvb.can.paas.cloudcenter.corp/harbor/projects/76/repositories/produban%2Fpython/tags/2.0.6.RELEASE).
This image is based on RHEL 7.4 Image and Python 3.6, exposes the port `8080` and the Python process is executed by the `python` user.
See [base image documentation](https://git.global.paas.gsnetcloud.corp/images/python/blob/2.0.6.RELEASE/README.md#how-to-use-image)
for general instructions regarding how to use the image.

## Environment variables

* **Required** environment variables:
  * **`ARTIFACT_URL`**: The URL of the Python distribution to run. It might be a **[source distribution](https://packaging.python.org/glossary#term-Source-Distribution-or-sdist)** or a **[Wheel distribution](https://packaging.python.org/glossary/#term-Wheel)**.
  * **`PROXY`**: The proxy to use for downloading dependencies when installing the distribution.

* **Optional** environment variables:
  * **`APP_MODULE`**: This is the name of the module and WSGI variable name in format `MODULE_NAME(:VARIABLE_NAME])?`, where
  `VARIABLE_NAME` part may not be specified it the module uses the default `application` WSGI variable name.

    If no module is specified, the process will attempt to discover the target module within the distribution archive following
    **Django** application structure conventions (_i.e._, `*/wsgi.py` files).
  * **`CONF_HOME`**: The path where Python configuration files will be made available.

    If not provided, the directory where the Python distribution is unpacked to will be used as configuration  directory.
  * **`GUNICORN_CONFIG`**: Path to the [Gunicorn configuration file](https://docs.gunicorn.org/en/stable/settings.html#config-file)
    to use for running Gunicorn.

    If not provided, the following configuration will be used as default:

    ```python
    bind='0.0.0.0:8080'
    ```

  * **`DJANGO_SETTINGS`**: If the Python distribution is a [Django-based](https://www.djangoproject.com/) WSGI application, the
    name of the [Django settings module](https://docs.djangoproject.com/en/2.1/topics/settings/) to use for running the application.
    The module may be either provided within the distribution or via the configuration directory.
