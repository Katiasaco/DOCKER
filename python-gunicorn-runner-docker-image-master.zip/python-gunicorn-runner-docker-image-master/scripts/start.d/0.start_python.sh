#!/usr/bin/env bash

#---------------------------------------------------------------------------------------------------------------------#
#-- Constants                                                                                                       --#
#---------------------------------------------------------------------------------------------------------------------#

readonly MISSING="###MISSING###"

readonly PREDEFINED_GUNICORN_CONFIG_FILE="gunicorn.conf.py"

readonly FAILURE_MISSING_ENVIRONMENT_VARIABLE=1
readonly FAILURE_INVALID_ENVIRONMENT_VARIABLE_VALUE=2
readonly FAILURE_COULD_NOT_DOWNLOAD_DISTRIBUTION=3
readonly FAILURE_COULD_NOT_INSTALL_DISTRIBUTION=4
readonly FAILURE_COULD_NOT_UNPACK_DISTRIBUTION=5
readonly FAILURE_INVALID_DISTRIBUTION_PACKAGE=6
readonly FAILURE_NO_WSGI_MODULE_AVAILABLE=7
readonly FAILURE_TOO_MANY_WSGI_MODULES_AVAILABLE=8

#---------------------------------------------------------------------------------------------------------------------#
#-- Shared auxiliar functions                                                                                       --#
#---------------------------------------------------------------------------------------------------------------------#

function info() {
  1>&2 echo "$*"
}

function error() {
  info "ERROR: $*"
}

function warning() {
  info "WARNING: $*"
}

function tryAssign() {
  local var="${1}"
  shift
  $* > .tmp
  read -r $var < .tmp
  rm -rf .tmp > /dev/null 2>&1
}

#---------------------------------------------------------------------------------------------------------------------#
#-- Setup specific functions                                                                                        --#
#---------------------------------------------------------------------------------------------------------------------#

function setup::init() {
  set -euo pipefail
  if shopt -p | grep inherit_errexit > /dev/null 2>&1; then
    shopt -s inherit_errexit
  fi
}

##
# Verify that expected environment variables are available
##
function setup::verify() {
  local dist_home="${1}"
  local artifact_url="${2}"
  local proxy="${3}"

  if [[ "${dist_home}" == "${MISSING}" ]]; then
    error "No DIST_HOME specified"
    return "${FAILURE_MISSING_ENVIRONMENT_VARIABLE}"
  fi

  if [[ ! -d "${dist_home}" ]]; then
    warning "Could not find DIST_HOME '${dist_home}'. Trying to create it now..."
    if ! log="$(mkdir -p "${dist_home}" 2>&1)"; then
      error "$(sed 's/mkdir: //' <<< "${log}")"
      return "${FAILURE_INVALID_ENVIRONMENT_VARIABLE_VALUE}"
    fi
  fi

  if [[ "${artifact_url}" == "${MISSING}" ]]; then
    error "No ARTIFACT_URL specified"
    return "${FAILURE_MISSING_ENVIRONMENT_VARIABLE}"
  fi

  if [[ "${proxy}" == "${MISSING}" ]]; then
    error "No PROXY specified."
    return "${FAILURE_MISSING_ENVIRONMENT_VARIABLE}"
  fi
}

#---------------------------------------------------------------------------------------------------------------------#
#-- Distribution Handling Specific functions                                                                        --#
#---------------------------------------------------------------------------------------------------------------------#

function distribution::setup() {
  distribution_url="${1}"
  distribution_file="$(basename "${distribution_url}")"
  distribution_file_path="/tmp/${distribution_file}"
  if [[ "${distribution_file}" != "${distribution_file/.tar.gz/}" ]]; then
    distribution_class=tarball
    distribution_meta=egg
    distribution_type="source distribution"
  elif [[ "${distribution_file}" != "${distribution_file/.whl/}" ]]; then
    distribution_class=wheel
    distribution_meta=dist
    distribution_type="Wheel built distribution"
  else
    error "Could not determine packaging format of distribution ${distribution_file}"
    return "${FAILURE_INVALID_ENVIRONMENT_VARIABLE_VALUE}"
  fi

  declare -gr distribution_url
  declare -gr distribution_file
  declare -gr distribution_file_path
  declare -gr distribution_class
  declare -gr distribution_meta
  declare -gr distribution_type
}

function distribution::download() {
  info "- Downloading ${distribution_type} from ${distribution_url}..."
  if ! wget -q --no-check-certificate --connect-timeout=5 --read-timeout=10 --tries=2 -O "${distribution_file_path}" "${distribution_url}"; then
    error "Could not download distribution from ${distribution_url}"
    return "${FAILURE_COULD_NOT_DOWNLOAD_DISTRIBUTION}"
  fi
}

function distribution::install() {
  local -r proxy="${1}"
  local -r beforeFile="$(mktemp -t)"
  local -r afterFile="$(mktemp -t)"
  local -r logFile="$(mktemp -t)"
  local -r installedFile="$(mktemp -t)"

  info "- Installing ${distribution_type} ${distribution_file}..."
  info "==== BEGIN PIP ===="
  pip list --format=legacy 2> /dev/null | sort > "${beforeFile}"
  if ! pip install "${distribution_file_path}" --proxy "${proxy}" | tee "${logFile}"; then
    error "Could not install ${distribution_type} ${distribution_file}"
    return "${FAILURE_COULD_NOT_INSTALL_DISTRIBUTION}"
  fi
  pip list --format=legacy 2> /dev/null | sort > "${afterFile}"
  info "====  END PIP  ===="

  comm -23 "${afterFile}" "${beforeFile}" > "${installedFile}"

  local -r data="$(grep -E '^Installing collected packages: ' "${logFile}" | sed 's/Installing collected packages: //;s/ //g')"
  IFS=',' read -r -a packageNames <<< "${data}" 
  local -r packageName="${packageNames[-1]}"
  local -r packageVersion="$(grep -E "^${packageName} " "${installedFile}" | sed -r "s/^${packageName} \((.*)\)$/\1/")"
  info "- Installed package ${packageName} version ${packageVersion}"
}

function distribution::unpack() {
  local -r target_directory="${1}"
  info "- Unpacking ${distribution_type} ${distribution_file}..."
  info "==== BEGIN UNPACK ===="
  case "${distribution_class}" in
    tarball)
      # TODO: Check that we can untar the source distribution
      tar -xzvf "${distribution_file_path}" --overwrite-dir -C "${target_directory}"
      ;;
    wheel)
      # TODO: Check that we can unzip the Wheel built distribution
      unzip -o "${distribution_file_path}" -d "${target_directory}"
      ;;
  esac
  info "====  END UNPACK  ===="
}

function distribution::execute() {
  local -r dist_dir="${1}"
  local -r config_dir="${2}"
  local -r gunicorn_config_file="${3}"
  shift 3

  local meta_dir
  local package_dir

  # Find the distribution root directory
  meta_dir="$(find "${dist_dir}" -type d -name "*.${distribution_meta}-info")";
  if [[ -z "${meta_dir:-}" ]]; then
    error "Could not find ${distribution_meta}-info directory in ${distribution_type} ${distribution_file}"
    return "${FAILURE_INVALID_DISTRIBUTION_PACKAGE}"
  fi
  package_dir="$(dirname "${meta_dir}")"

  local configDir
  local gunicornConfigFile
  local pythonPath

  tryAssign configDir config::homeDir "${package_dir}" "${config_dir}"
  tryAssign gunicornConfigFile config::gunicornConfig "${package_dir}" "${configDir}" "${gunicorn_config_file}"
  tryAssign pythonPath config::pythonPath "${package_dir}" "${configDir}"

  django::execute "${package_dir}" "${gunicornConfigFile}" "${pythonPath}" $*
}


#---------------------------------------------------------------------------------------------------------------------#
#-- Configuration specific functions                                                                                --#
#---------------------------------------------------------------------------------------------------------------------#

function config::homeDir() {
  local -r package_dir="${1}"
  local -r config_dir="${2}"

  local configDir
  if [[ "${config_dir}" != "${MISSING}" ]]; then
    if [[ -d ${config_dir} ]]; then
        info "- Using configuration directory ${config_dir}..."
        configDir="${config_dir}"
    else
        warning "Could not find configuration directory ${config_dir}. Falling back to distribution directory..."
        configDir="${package_dir}"
    fi
  else
      warning "No configuration directory specified. Using distribution directory..."
      configDir="${package_dir}"
  fi

  echo "${configDir}"
}

function config::gunicornConfig() {
  local -r package_dir="${1}"
  local -r config_dir="${2}"
  local -r gunicorn_config_file="${3}"

  local -a sources=( )
  local -a candidates=( )

  if [[ "${gunicorn_config_file}" != "${MISSING}" ]]; then
    candidates+=( "${gunicorn_config_file}" )
    sources+=( 'custom')
  fi

  if [[ "${config_dir}" == "${package_dir}" ]]; then
    candidates+="${package_dir}/${PREDEFINED_GUNICORN_CONFIG_FILE}"
    sources+=( 'distribution-provided' )
  else
    candidates+=( "${config_dir}/${PREDEFINED_GUNICORN_CONFIG_FILE}")
    sources+=( 'config-provided' )

    candidates+=( "${package_dir}/${PREDEFINED_GUNICORN_CONFIG_FILE}" )
    sources+=( 'distribution-provided' )
  fi

  local gunicornConfigFile
  local gcfSource

  info "- Looking for Gunicorn configuration file..."
  for key in "${!sources[@]}"; do
    source="${sources[${key}]}"
    candidate="${candidates[${key}]}"
    if [[ -f "${candidate}" ]]; then
      gunicornConfigFile="${candidate}"
      gcfSource="${source}"
      break
    fi
    info "  + ${source^} Gunicorn configuration ${candidate} file not found."
  done

  if [[ -z "${gunicornConfigFile:-}" ]]; then
    warning "No Gunicorn configuration file available. Generating default ${PREDEFINED_GUNICORN_CONFIG_FILE} configuration..."
    local -r temp_dir="$(mktemp -t -d)"
    gunicornConfigFile="${temp_dir}/${PREDEFINED_GUNICORN_CONFIG_FILE}"
    cat > "${gunicornConfigFile}" <<- EOF
bind='0.0.0.0:8080'
EOF
    gcfSource="generated"
  fi
  info "- Using ${gcfSource} Gunicorn configuration file ${gunicornConfigFile}..."

  echo "${gunicornConfigFile}"
}

function config::pythonPath() {
  local -r package_dir="${1}"
  local -r config_dir="${2}"

  local pythonPath
  if [[ "${package_dir}" != "${config_dir}" ]]; then
    info "- Using Python path ${config_dir}..."
    pythonPath="${config_dir}"
  else
    pythonPath="$(mktemp -t -d)"
  fi

  echo "${pythonPath}"
}

#---------------------------------------------------------------------------------------------------------------------#
#-- Django Specific functions                                                                                       --#
#---------------------------------------------------------------------------------------------------------------------#

function django::execute() {
  local -r package_dir="${1}"
  local -r gunicorn_config_file="${2}"
  local -r python_path="${3}"
  local -r wsgi_module="${4}"

  local settings
  if [[ -n "${DJANGO_SETTINGS:-}" ]]; then
    info "- Using Django settings module ${DJANGO_SETTINGS}..."
    settings="DJANGO_SETTINGS_MODULE=${DJANGO_SETTINGS}"
  else
    settings=""
  fi

  local wsgiModule
  local wmSource
  # Find out which module will have to be run...
  if [[ "${wsgi_module}" != "${MISSING}" ]]; then
    wsgiModule="${wsgi_module}"
    wmSource="custom"
  else
    warning "No APP_MODULE specified! Discovering candidate Django WSGI modules..."
    tryAssign wsgiModule django::discoverWSGIModule "${package_dir}"
    wmSource="discovered"
  fi
  info "- Selected ${wmSource} ${wsgiModule} WSGI module for running with Gunicorn..."

  # Get into the source directory
  cd "${package_dir}" > /dev/null 2>&1

  # Execute module with Gunicorn
  gunicorn::executeWSGIModule  \
    "${gunicorn_config_file}"  \
    "${python_path}"           \
    "${wsgiModule}"            \
    "${settings}"
}

function django::discoverWSGIModule() {
  local -r package_dir="${1}"
  local wsgiModule
  local candidates

  wsgiModule="$(find "${package_dir}" -depth -type f -name 'wsgi.py' -not -path './rh/*' | sed -r "s:^${package_dir}::" | sed 's:/:.:g;s:^\.\+::;s:\.py$::')"
  if [[ -z "${wsgiModule:-}" ]]; then
    error "Could not find any Django WSGI module suitable for execution"
    return "${FAILURE_NO_WSGI_MODULE_AVAILABLE}"
  fi
  candidates="$(wc -l <<< "${wsgiModule}")"
  if [[ "${candidates}" -gt 1 ]]; then
    error "Too many Django WSGI modules suitable for execution"
    info "- The following Django WSGI modules were found:"
    while read -r candidate; do
      info "  + ${candidate}"
    done <<< "${wsgiModule}"
    return "${FAILURE_TOO_MANY_WSGI_MODULES_AVAILABLE}"
  fi

  echo "${wsgiModule}"
}

#---------------------------------------------------------------------------------------------------------------------#
#-- Gunicorn Specific functions                                                                                     --#
#---------------------------------------------------------------------------------------------------------------------#

function gunicorn::executeWSGIModule() {
  local -r configFile="${1}"
  local -r pythonPath="${2}"
  local -r wsgiModule="${3}"
  shift 3

  # Prepare command line parameters
  local cmdLineParams="--config ${configFile} --pythonpath ${pythonPath}"
  while [[ $# -gt 0 ]]; do
    if [[ -n "${1:-}" ]]; then
      cmdLineParams="${cmdLineParams} --env ${1}"
    fi
    shift
  done
  cmdLineParams="${cmdLineParams} ${wsgiModule}"

  # Launch Gunicorn
  info "==== LAUNCHING Gunicorn (${wsgiModule}) ===="
  exec gunicorn ${cmdLineParams}
}

#---------------------------------------------------------------------------------------------------------------------#
#-- Main                                                                                                            --#
#---------------------------------------------------------------------------------------------------------------------#

info "========================================="
info "Starting application"
info "========================================="

setup::init
setup::verify                     \
    "${DIST_HOME:-${MISSING}}"    \
    "${ARTIFACT_URL:-${MISSING}}" \
    "${PROXY:-${MISSING}}"

distribution::setup "${ARTIFACT_URL}"

distribution::download
distribution::install "${PROXY}"

# No way to know the proxy beyond this point
unset PROXY

distribution::unpack "${DIST_HOME}"
distribution::execute                \
    "${DIST_HOME}"                   \
    "${CONF_HOME:-${MISSING}}"       \
    "${GUNICORN_CONFIG:-${MISSING}}" \
    "${APP_MODULE:-${MISSING}}"
